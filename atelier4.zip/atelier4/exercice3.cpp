#include <iostream>
#include <list>
using namespace std;
int main()
{
    list<int> maliste;   
    int n;
    int i;
    int X;
    cout<<"entrer les chiffres a inserer"<<endl;
    for (i = 0;; i++) // boucle for va se reperter indeterminer de fois mais il va s'arreter lorsque on fait n==0 
    {
    cout<<"entrer L'entier "<<i<<endl;
    cin>>n;
    if(n==0)// on va tester si n qu'on a sais == 0 pour sorter de la boucle
    {
        break;  
    }
    maliste.push_back(n); 
    }
    list<int>::iterator it;  
    maliste.sort();    
    it=maliste.begin();
    cout<<"votre liste de nombre triee est : ";
    for (it;it!=maliste.end();it++)  
    {
            cout<<*it<<"  ";
    }
}
