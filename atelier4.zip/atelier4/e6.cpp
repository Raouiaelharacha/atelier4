
#include<iostream>
#include <exception>
using namespace std;
class Test{
public:
static int tableau[] ;
public :
static int division(int indice, int diviseur){

if(diviseur == 0 && (indice<0 || indice>10))
       throw "Division par zero !! , l'indice invalide";// mesg d'erreur
else if (diviseur == 0 )
throw "Division par zero !!";
else if(indice<0 || indice>10)  
        throw "l'indice invalide";
       
return tableau[indice]/diviseur;
}
};
int Test::tableau[] = {17, 12, 15, 38, 29, 157, 89, -22, 0, 5} ;
int main()
{
int x, y;

cout<<endl<<"Entrez l'indice de l'entier a diviser: ";
cin>>x ;
cout<<endl<<"Entrez le diviseur: ";
cin>>y ;

  try{
        cout<< "Le resultat de la division est: "<<endl<<Test::division(x,y) <<endl;
}catch(const char* msg){// si ona les cas d'erreur catch va s'executer et afficher msg de throw mgs === a la valeur inserer dans throw
// catch ne va pas s'executer si
cerr<<msg;
}

return 0;
}
